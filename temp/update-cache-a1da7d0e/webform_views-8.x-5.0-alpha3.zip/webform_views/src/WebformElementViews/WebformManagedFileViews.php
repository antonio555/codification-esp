<?php

namespace Drupal\webform_views\WebformElementViews;

/**
 * Default webform views handler for managed file webform elements.
 */
class WebformManagedFileViews extends WebformElementViewsAbstract {
}
